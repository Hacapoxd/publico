package models;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PlanPracticas {
    private int id;
    private int estudianteId;
    private String documentoPlan;  // ruta o link al archivo
    private String objetivos;
    private String cronograma;
    private BigDecimal presupuesto;
    private Timestamp fechaSubida;
    private String estado;         // pendiente, aceptado, rechazado
    private String comentarios;
    private Timestamp fechaRevision;

    public PlanPracticas() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public String getDocumentoPlan() {
        return documentoPlan;
    }

    public String getObjetivos() {
        return objetivos;
    }

    public String getCronograma() {
        return cronograma;
    }

    public BigDecimal getPresupuesto() {
        return presupuesto;
    }

    public Timestamp getFechaSubida() {
        return fechaSubida;
    }

    public String getEstado() {
        return estado;
    }

    public String getComentarios() {
        return comentarios;
    }

    public Timestamp getFechaRevision() {
        return fechaRevision;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setDocumentoPlan(String documentoPlan) {
        this.documentoPlan = documentoPlan;
    }

    public void setObjetivos(String objetivos) {
        this.objetivos = objetivos;
    }

    public void setCronograma(String cronograma) {
        this.cronograma = cronograma;
    }

    public void setPresupuesto(BigDecimal presupuesto) {
        this.presupuesto = presupuesto;
    }

    public void setFechaSubida(Timestamp fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public void setFechaRevision(Timestamp fechaRevision) {
        this.fechaRevision = fechaRevision;
    }
}
