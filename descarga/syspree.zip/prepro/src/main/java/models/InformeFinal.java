package models;

import java.sql.Timestamp;

public class InformeFinal {
    private int id;
    private int estudianteId;
    private String archivoPdf;      // ruta o link al archivo PDF
    private Timestamp fechaSubida;
    private String resumenResultados;

    public InformeFinal() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public String getArchivoPdf() {
        return archivoPdf;
    }

    public Timestamp getFechaSubida() {
        return fechaSubida;
    }

    public String getResumenResultados() {
        return resumenResultados;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setArchivoPdf(String archivoPdf) {
        this.archivoPdf = archivoPdf;
    }

    public void setFechaSubida(Timestamp fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    public void setResumenResultados(String resumenResultados) {
        this.resumenResultados = resumenResultados;
    }
}
