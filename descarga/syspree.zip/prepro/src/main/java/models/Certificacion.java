package models;

import java.sql.Timestamp;

public class Certificacion {
    private int id;
    private int estudianteId;
    private String archivoConstancia;
    private Timestamp fechaSubida;
    private String entidadEmisora;

    public Certificacion() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public String getArchivoConstancia() {
        return archivoConstancia;
    }

    public Timestamp getFechaSubida() {
        return fechaSubida;
    }

    public String getEntidadEmisora() {
        return entidadEmisora;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setArchivoConstancia(String archivoConstancia) {
        this.archivoConstancia = archivoConstancia;
    }

    public void setFechaSubida(Timestamp fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    public void setEntidadEmisora(String entidadEmisora) {
        this.entidadEmisora = entidadEmisora;
    }
}
