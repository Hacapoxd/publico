package models.dao;

import config.Conexion;
import models.Administrador;

import java.sql.*;

public class AdministradorDAO {

    public Administrador login(String correo, String clave) {
        Administrador admin = null;
        String sql = "SELECT * FROM administrador WHERE correo = ? AND clave = ?";

        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, correo);
            ps.setString(2, clave);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    admin = new Administrador();
                    admin.setId(rs.getInt("id"));
                    admin.setCorreo(rs.getString("correo"));
                    admin.setClave(rs.getString("clave"));
                    admin.setNombre(rs.getString("nombre"));
                    admin.setApellido(rs.getString("apellido"));
                    admin.setTelefono(rs.getString("telefono"));
                    admin.setDni(rs.getString("dni"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return admin;
    }

    // Puedes agregar métodos como registrar, actualizar, eliminar, etc.
}

