package models.dao;

import config.Conexion;
import models.Evaluacion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EvaluacionDAO {
    private static final Logger LOGGER = Logger.getLogger(EvaluacionDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public Evaluacion obtenerPorId(int id) {
        Evaluacion eva = null;
        String sql = "SELECT * FROM evaluaciones WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                eva = new Evaluacion();
                eva.setId(rs.getInt("id"));
                eva.setProductoId(rs.getInt("producto_id"));
                eva.setDocenteId(rs.getInt("docente_id"));
                eva.setFechaEvaluacion(rs.getTimestamp("fecha_evaluacion"));
                eva.setCalificacion(rs.getDouble("calificacion"));
                eva.setComentarios(rs.getString("comentarios"));
                eva.setRubrica(rs.getString("rubrica"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId Evaluacion", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return eva;
    }
}
