package models.dao;

import config.Conexion;
import models.JuradoAsignacion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JuradoAsignacionDAO {
    private static final Logger LOGGER = Logger.getLogger(JuradoAsignacionDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public JuradoAsignacion obtenerPorId(int id) {
        JuradoAsignacion asignacion = null;
        String sql = "SELECT * FROM jurados_asignaciones WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if(rs.next()) {
                asignacion = new JuradoAsignacion();
                asignacion.setId(rs.getInt("id"));
                asignacion.setJuradoId(rs.getInt("jurado_id"));
                asignacion.setSustentacionId((Integer) rs.getObject("sustentacion_id"));
                asignacion.setProductoId((Integer) rs.getObject("producto_id"));
                asignacion.setFechaAsignacion(rs.getTimestamp("fecha_asignacion"));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error obteniendo JuradoAsignacion", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch (SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return asignacion;
    }
}
