package models.dao;

import config.Conexion;
import models.Sustentacion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SustentacionDAO {
    private static final Logger LOGGER = Logger.getLogger(SustentacionDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public Sustentacion obtenerPorId(int id) {
        Sustentacion sus = null;
        String sql = "SELECT * FROM sustentaciones WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                sus = new Sustentacion();
                sus.setId(rs.getInt("id"));
                sus.setEstudianteId(rs.getInt("estudiante_id"));
                sus.setFecha(rs.getDate("fecha"));
                sus.setHora(rs.getTime("hora"));
                sus.setLugar(rs.getString("lugar"));
                int jurado = rs.getInt("jurado_asignado");
                sus.setJuradoAsignado(rs.wasNull() ? null : jurado);
                sus.setEstado(rs.getString("estado"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId Sustentacion", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return sus;
    }
}
