
package models.dao;

import config.Conexion;
import models.Evidencia;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EvidenciaDAO {
    private static final Logger LOGGER = Logger.getLogger(EvidenciaDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public Evidencia obtenerPorId(int id) {
        Evidencia evi = null;
        String sql = "SELECT * FROM evidencias WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                evi = new Evidencia();
                evi.setId(rs.getInt("id"));
                evi.setProductoId(rs.getInt("producto_id"));
                evi.setArchiEvidencia(rs.getString("archi_evidencia"));
                evi.setFechaSubida(rs.getTimestamp("fecha_subida"));
                evi.setDescripcion(rs.getString("descripcion"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId Evidencia", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return evi;
    }
}
