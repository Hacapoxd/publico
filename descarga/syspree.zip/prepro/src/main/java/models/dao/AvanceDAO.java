package models.dao;

import config.Conexion;
import models.Avance;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AvanceDAO {
    private static final Logger LOGGER = Logger.getLogger(AvanceDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public Avance obtenerPorId(int id) {
        Avance av = null;
        String sql = "SELECT * FROM avances WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                av = new Avance();
                av.setId(rs.getInt("id"));
                av.setEstudianteId(rs.getInt("estudiante_id"));
                av.setDescripcion(rs.getString("descripcion"));
                av.setFechaRegistro(rs.getTimestamp("fecha_registro"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId Avance", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return av;
    }
}

