package models.dao;

import config.Conexion;
import models.Docente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DocenteDAO {

    public Docente buscarPorId(int id) {
        Docente docente = null;
        String sql = "SELECT * FROM docente WHERE id = ?";

        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    docente = new Docente();
                    docente.setId(rs.getInt("id"));
                    docente.setIdUsuario(rs.getInt("id_usuario"));
                    docente.setApellidoPaterno(rs.getString("apellido_paterno"));
                    docente.setApellidoMaterno(rs.getString("apellido_materno"));
                    docente.setNombres(rs.getString("nombres"));
                    docente.setDni(rs.getString("dni"));
                    docente.setTelefono(rs.getString("telefono"));
                    docente.setCorreo(rs.getString("correo"));
                    docente.setEscuelaId(rs.getInt("escuela_id"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return docente;
    }
    
    public Docente login(String correo, String clave) {
    Docente docente = null;
    String sql = "SELECT * FROM docente WHERE correo = ? AND clave = ?";

    try (Connection cn = Conexion.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql)) {

        ps.setString(1, correo);
        ps.setString(2, clave);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                docente = new Docente();
                docente.setId(rs.getInt("id"));
                docente.setIdUsuario(rs.getInt("id_usuario"));
                docente.setApellidoPaterno(rs.getString("apellido_paterno"));
                docente.setApellidoMaterno(rs.getString("apellido_materno"));
                docente.setNombres(rs.getString("nombres"));
                docente.setDni(rs.getString("dni"));
                docente.setTelefono(rs.getString("telefono"));
                docente.setCorreo(rs.getString("correo"));
                docente.setEscuelaId(rs.getInt("escuela_id"));
                docente.setClave(rs.getString("clave"));
                // puedes agregar más campos si lo deseas
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return docente;
}
    public boolean registrar(Docente docente) {
        String sql = "INSERT INTO docente (id_usuario, apellido_paterno, apellido_materno, nombres, dni, telefono, correo, escuela_id, clave) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, docente.getIdUsuario());
            ps.setString(2, docente.getApellidoPaterno());
            ps.setString(3, docente.getApellidoMaterno());
            ps.setString(4, docente.getNombres());
            ps.setString(5, docente.getDni());
            ps.setString(6, docente.getTelefono());
            ps.setString(7, docente.getCorreo());
            ps.setInt(8, docente.getEscuelaId());
            ps.setString(9, docente.getClave());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Puedes agregar otros métodos como insertar, listar, actualizar, eliminar si lo necesitas
}
