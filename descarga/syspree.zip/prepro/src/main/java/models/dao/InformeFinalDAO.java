package models.dao;

import config.Conexion;
import models.InformeFinal;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InformeFinalDAO {
    private static final Logger LOGGER = Logger.getLogger(InformeFinalDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public InformeFinal obtenerPorId(int id) {
        InformeFinal inf = null;
        String sql = "SELECT * FROM informe_final WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                inf = new InformeFinal();
                inf.setId(rs.getInt("id"));
                inf.setEstudianteId(rs.getInt("estudiante_id"));
                inf.setArchivoPdf(rs.getString("archivo_pdf"));
                inf.setFechaSubida(rs.getTimestamp("fecha_subida"));
                inf.setResumenResultados(rs.getString("resumen_resultados"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId InformeFinal", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return inf;
    }
}
