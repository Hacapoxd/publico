package models.dao;

import config.Conexion;
import models.Notificacion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NotificacionDAO {
    private static final Logger LOGGER = Logger.getLogger(NotificacionDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    // Obtener notificaciones por destinatario
    public List<Notificacion> listarPorDestinatario(int destinatarioId) {
        List<Notificacion> lista = new ArrayList<>();
        String sql = "SELECT * FROM notificaciones WHERE destinatario_id = ? ORDER BY fecha_envio DESC";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, destinatarioId);
            rs = ps.executeQuery();

            while (rs.next()) {
                Notificacion n = new Notificacion();
                n.setId(rs.getInt("id"));
                n.setDestinatarioId(rs.getInt("destinatario_id"));
                n.setMensaje(rs.getString("mensaje"));
                n.setFechaEnvio(rs.getTimestamp("fecha_envio"));
                n.setLeido(rs.getBoolean("leido"));
                lista.add(n);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error listando notificaciones", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); } 
            catch (SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return lista;
    }

    // Marcar notificación como leída
    public boolean marcarLeida(int id) {
        String sql = "UPDATE notificaciones SET leido = TRUE WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error marcando notificación leída", e);
            return false;
        } finally {
            try { if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch (SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
    }
}
