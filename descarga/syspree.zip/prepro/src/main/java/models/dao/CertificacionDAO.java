package models.dao;

import config.Conexion;
import models.Certificacion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CertificacionDAO {
    private static final Logger LOGGER = Logger.getLogger(CertificacionDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public Certificacion obtenerPorId(int id) {
        Certificacion cert = null;
        String sql = "SELECT * FROM certificaciones WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                cert = new Certificacion();
                cert.setId(rs.getInt("id"));
                cert.setEstudianteId(rs.getInt("estudiante_id"));
                cert.setArchivoConstancia(rs.getString("archivo_constancia"));
                cert.setFechaSubida(rs.getTimestamp("fecha_subida"));
                cert.setEntidadEmisora(rs.getString("entidad_emisora"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId Certificacion", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return cert;
    }
}

