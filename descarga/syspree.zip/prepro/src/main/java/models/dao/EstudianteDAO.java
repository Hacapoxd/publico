package models.dao;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.Estudiante;

public class EstudianteDAO {

    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public List<Estudiante> listar() {
        List<Estudiante> lista = new ArrayList<>();
        String sql = "SELECT * FROM estudiante";

        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Estudiante e = new Estudiante();
                e.setId(rs.getInt("id"));
                e.setCodigoUnv(rs.getString("codigo_unv"));
                e.setSemestreMatriculado(rs.getString("semestre_matriculado"));
                e.setApellidoPaterno(rs.getString("apellido_paterno"));
                e.setApellidoMaterno(rs.getString("apellido_materno"));
                e.setNombres(rs.getString("nombres"));
                e.setDni(rs.getString("dni"));
                e.setCelular(rs.getString("celular"));
                lista.add(e);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (cn != null) cn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return lista;
    }
    
    public Estudiante buscarPorId(int id) {
        Estudiante est = null;
        String sql = "SELECT * FROM estudiante WHERE id = ?";

        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    est = new Estudiante();
                    est.setId(rs.getInt("id"));
                    est.setCodigoUnv(rs.getString("codigo_unv"));
                    est.setSemestreMatriculado(rs.getString("semestre_matriculado"));
                    est.setApellidoPaterno(rs.getString("apellido_paterno"));
                    est.setApellidoMaterno(rs.getString("apellido_materno"));
                    est.setNombres(rs.getString("nombres"));
                    est.setDni(rs.getString("dni"));
                    est.setCelular(rs.getString("celular"));
                    est.setCorreo(rs.getString("correo"));
                    est.setDireccion(rs.getString("direccion"));
                    est.setEscuelaId(rs.getInt("escuela_id"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Puedes usar Logger si prefieres
        }

        return est;
    }
    
    public void registrar(Estudiante estudiante) {
        String sql = "INSERT INTO estudiante (codigo_unv, semestre_matriculado, apellido_paterno, apellido_materno, " +
                     "nombres, dni, celular, correo, direccion, escuela_id, clave) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);

            ps.setString(1, estudiante.getCodigoUnv());
            ps.setString(2, estudiante.getSemestreMatriculado());
            ps.setString(3, estudiante.getApellidoPaterno());
            ps.setString(4, estudiante.getApellidoMaterno());
            ps.setString(5, estudiante.getNombres());
            ps.setString(6, estudiante.getDni());
            ps.setString(7, estudiante.getCelular());
            ps.setString(8, estudiante.getCorreo());
            ps.setString(9, estudiante.getDireccion());
            ps.setInt(10, estudiante.getEscuelaId());
            ps.setString(11, estudiante.getClave());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace(); // Mostrar el error en consola (para depuración)
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (cn != null) cn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public Estudiante login(String codigo_unv, String clave) {
        Estudiante est = null;
        String sql = "SELECT * FROM estudiante WHERE codigo_unv = ? AND clave = ?";

        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, codigo_unv);
            ps.setString(2, clave);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    est = new Estudiante();
                    est.setId(rs.getInt("id"));
                    est.setCodigoUnv(rs.getString("codigo_unv"));
                    est.setSemestreMatriculado(rs.getString("semestre_matriculado"));
                    est.setApellidoPaterno(rs.getString("apellido_paterno"));
                    est.setApellidoMaterno(rs.getString("apellido_materno"));
                    est.setNombres(rs.getString("nombres"));
                    est.setDni(rs.getString("dni"));
                    est.setCelular(rs.getString("celular"));
                    est.setCorreo(rs.getString("correo"));
                    est.setDireccion(rs.getString("direccion"));
                    est.setEscuelaId(rs.getInt("escuela_id"));
                    est.setClave(rs.getString("clave"));  // Si lo necesitas
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return est;
    }
}


