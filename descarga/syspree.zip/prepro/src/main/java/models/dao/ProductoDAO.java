package models.dao;

import config.Conexion;
import models.Producto;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProductoDAO {
    private static final Logger LOGGER = Logger.getLogger(ProductoDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public Producto obtenerPorId(int id) {
        Producto prod = null;
        String sql = "SELECT * FROM productos WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if(rs.next()) {
                prod = new Producto();
                prod.setId(rs.getInt("id"));
                prod.setEstudianteId(rs.getInt("estudiante_id"));
                prod.setTipoProducto(rs.getString("tipo_producto"));
                prod.setDescripcion(rs.getString("descripcion"));
                prod.setFechaCreacion(rs.getDate("fecha_creacion"));
            }
        } catch(SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId Producto", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); }
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return prod;
    }
}
