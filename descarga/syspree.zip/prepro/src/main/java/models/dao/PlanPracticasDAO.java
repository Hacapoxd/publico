
package models.dao;

import config.Conexion;
import models.PlanPracticas;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PlanPracticasDAO {
    private static final Logger LOGGER = Logger.getLogger(PlanPracticasDAO.class.getName());
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public PlanPracticas obtenerPorId(int id) {
        PlanPracticas plan = null;
        String sql = "SELECT * FROM plan_practicas WHERE id = ?";
        try {
            cn = Conexion.getConnection();
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
                plan = new PlanPracticas();
                plan.setId(rs.getInt("id"));
                plan.setEstudianteId(rs.getInt("estudiante_id"));
                plan.setDocumentoPlan(rs.getString("documento_plan"));
                plan.setObjetivos(rs.getString("objetivos"));
                plan.setCronograma(rs.getString("cronograma"));
                plan.setPresupuesto(rs.getBigDecimal("presupuesto"));
                plan.setFechaSubida(rs.getTimestamp("fecha_subida"));
                plan.setEstado(rs.getString("estado"));
                plan.setComentarios(rs.getString("comentarios"));
                plan.setFechaRevision(rs.getTimestamp("fecha_revision"));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error en obtenerPorId PlanPracticas", e);
        } finally {
            try { if(rs != null) rs.close(); if(ps != null) ps.close(); if(cn != null) cn.close(); } 
            catch(SQLException e) { LOGGER.log(Level.WARNING, "Error cerrando recursos", e); }
        }
        return plan;
    }
}
