
package models;

public class Usuario {
    private int idUsuario;
    private String correo;
    private String contraseñaHash;
    private int idRol;
    private boolean activo;

    public Usuario() {}

    // Getters
    public int getIdUsuario() {
        return idUsuario;
    }

    public String getCorreo() {
        return correo;
    }

    public String getContraseñaHash() {
        return contraseñaHash;
    }

    public int getIdRol() {
        return idRol;
    }

    public boolean isActivo() {
        return activo;
    }

    // Setters
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setContraseñaHash(String contraseñaHash) {
        this.contraseñaHash = contraseñaHash;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}

