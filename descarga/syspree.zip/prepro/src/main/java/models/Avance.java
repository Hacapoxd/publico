package models;

import java.sql.Timestamp;

public class Avance {
    private int id;
    private int estudianteId;
    private String descripcion;
    private Timestamp fechaRegistro;

    public Avance() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}


