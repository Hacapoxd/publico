package models;

import java.sql.Date;
import java.sql.Time;

public class Sustentacion {
    private int id;
    private int estudianteId;
    private Date fecha;
    private Time hora;
    private String lugar;
    private Integer juradoAsignado;  // puede ser null
    private String estado;           // programada, realizada, cancelada

    public Sustentacion() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public Date getFecha() {
        return fecha;
    }

    public Time getHora() {
        return hora;
    }

    public String getLugar() {
        return lugar;
    }

    public Integer getJuradoAsignado() {
        return juradoAsignado;
    }

    public String getEstado() {
        return estado;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public void setJuradoAsignado(Integer juradoAsignado) {
        this.juradoAsignado = juradoAsignado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
