package models;

import java.sql.Timestamp;

public class Evidencia {
    private int id;
    private int productoId;
    private String archiEvidencia;  // ruta o link al archivo
    private Timestamp fechaSubida;
    private String descripcion;

    public Evidencia() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getProductoId() {
        return productoId;
    }

    public String getArchiEvidencia() {
        return archiEvidencia;
    }

    public Timestamp getFechaSubida() {
        return fechaSubida;
    }

    public String getDescripcion() {
        return descripcion;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setProductoId(int productoId) {
        this.productoId = productoId;
    }

    public void setArchiEvidencia(String archiEvidencia) {
        this.archiEvidencia = archiEvidencia;
    }

    public void setFechaSubida(Timestamp fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
