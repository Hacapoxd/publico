package models;

import java.sql.Timestamp;

public class JuradoAsignacion {
    private int id;
    private int juradoId;
    private Integer sustentacionId; // puede ser null
    private Integer productoId;     // puede ser null
    private Timestamp fechaAsignacion;

    public JuradoAsignacion() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getJuradoId() {
        return juradoId;
    }

    public Integer getSustentacionId() {
        return sustentacionId;
    }

    public Integer getProductoId() {
        return productoId;
    }

    public Timestamp getFechaAsignacion() {
        return fechaAsignacion;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setJuradoId(int juradoId) {
        this.juradoId = juradoId;
    }

    public void setSustentacionId(Integer sustentacionId) {
        this.sustentacionId = sustentacionId;
    }

    public void setProductoId(Integer productoId) {
        this.productoId = productoId;
    }

    public void setFechaAsignacion(Timestamp fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }
}

