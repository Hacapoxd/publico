package models;

import java.sql.Date;

public class Producto {
    private int id;
    private int estudianteId;
    private String tipoProducto; 
    private String descripcion;
    private Date fechaCreacion;

    public Producto() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
