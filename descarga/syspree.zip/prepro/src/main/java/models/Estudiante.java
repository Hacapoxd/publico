package models;


public class Estudiante {
    private int id;
    private String codigoUnv;
    private String semestreMatriculado;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String nombres;
    private String dni;
    private String celular;
    private String correo;
    private String direccion;
    private int escuelaId;

    // Constructor vacío
    public Estudiante() {}

    // Getters y Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigoUnv() {
        return codigoUnv;
    }

    public void setCodigoUnv(String codigoUnv) {
        this.codigoUnv = codigoUnv;
    }

    public String getSemestreMatriculado() {
        return semestreMatriculado;
    }

    public void setSemestreMatriculado(String semestreMatriculado) {
        this.semestreMatriculado = semestreMatriculado;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    
    public String getCorreo() {
        return correo;
    } 
    
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    public String getDireccion() {
        return direccion;
    } 
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public int getEscuelaId() {
        return escuelaId;
    } 

    public void setEscuelaId(int escuelaId) {
        this.escuelaId = escuelaId;
    }
    private String clave;

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
}
