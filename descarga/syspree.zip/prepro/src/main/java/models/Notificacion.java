package models;

import java.sql.Timestamp;

public class Notificacion {
    private int id;
    private int destinatarioId;
    private String mensaje;
    private Timestamp fechaEnvio;
    private boolean leido;

    public Notificacion() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getDestinatarioId() {
        return destinatarioId;
    }

    public String getMensaje() {
        return mensaje;
    }

    public Timestamp getFechaEnvio() {
        return fechaEnvio;
    }

    public boolean isLeido() {
        return leido;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setDestinatarioId(int destinatarioId) {
        this.destinatarioId = destinatarioId;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public void setFechaEnvio(Timestamp fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public void setLeido(boolean leido) {
        this.leido = leido;
    }
}
