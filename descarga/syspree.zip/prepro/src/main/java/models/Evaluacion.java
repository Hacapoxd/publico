package models;

import java.sql.Timestamp;

public class Evaluacion {
    private int id;
    private int productoId;
    private int docenteId;
    private Timestamp fechaEvaluacion;
    private double calificacion;
    private String comentarios;
    private String rubrica; // JSON almacenado como String

    public Evaluacion() {}

    // Getters
    public int getId() {
        return id;
    }

    public int getProductoId() {
        return productoId;
    }

    public int getDocenteId() {
        return docenteId;
    }

    public Timestamp getFechaEvaluacion() {
        return fechaEvaluacion;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public String getComentarios() {
        return comentarios;
    }

    public String getRubrica() {
        return rubrica;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setProductoId(int productoId) {
        this.productoId = productoId;
    }

    public void setDocenteId(int docenteId) {
        this.docenteId = docenteId;
    }

    public void setFechaEvaluacion(Timestamp fechaEvaluacion) {
        this.fechaEvaluacion = fechaEvaluacion;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public void setRubrica(String rubrica) {
        this.rubrica = rubrica;
    }
}
