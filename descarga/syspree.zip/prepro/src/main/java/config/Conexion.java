package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String URL = "jdbc:postgresql://localhost:5432/practicas_db";
    private static final String USER = "postgres";
    private static final String PASSWORD = "142536";

    // Método para obtener una conexión
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // Cargar el driver de PostgreSQL (opcional a partir de Java 6+)
            Class.forName("org.postgresql.Driver");

            // Establecer la conexión
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a PostgreSQL");
        } catch (ClassNotFoundException e) {
            System.out.println("Error: no se encontró el driver de PostgreSQL.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos.");
            e.printStackTrace();
        }
        return conn;
    }
}
