
package controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Docente;
import models.dao.DocenteDAO;
import models.dao.AvanceDAO;
import models.dao.EvaluacionDAO;
import models.dao.PlanPracticasDAO;
import models.dao.SustentacionDAO;

@WebServlet("/docente/*")
public class DocenteController extends HttpServlet {

    private final PlanPracticasDAO planDao = new PlanPracticasDAO();
    private final AvanceDAO avanceDao = new AvanceDAO();
    private final EvaluacionDAO evalDao = new EvaluacionDAO();
    private final SustentacionDAO sustDao = new SustentacionDAO();

     @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        switch (path) {
            case "/login" -> {
                req.getRequestDispatcher("/views/logd.jsp").forward(req, resp);
            }
            case "/principal" -> {
                if (!isDocente(req)) {
                    resp.sendRedirect(req.getContextPath() + "/docente/login");
                    return;
                }
                req.getRequestDispatcher("/views/DPrincipal.jsp").forward(req, resp);
            }
            default -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        switch (path) {
            case "/login" -> loginDocente(req, resp);
            default -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void loginDocente(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String correo = req.getParameter("correo");
        String clave = req.getParameter("clave");

        DocenteDAO dao = new DocenteDAO();
        Docente docente = dao.login(correo, clave);  // Usamos correo

        if (docente != null) {
            req.getSession().setAttribute("usuario", docente);
            resp.sendRedirect(req.getContextPath() + "/docente/principal");
        } else {
            req.setAttribute("error", "Correo o contraseña incorrectos.");
            req.getRequestDispatcher("/views/logd.jsp").forward(req, resp);
        }
    }
    private boolean isDocente(HttpServletRequest req) {
    return req.getSession().getAttribute("usuario") != null;
    }
}

