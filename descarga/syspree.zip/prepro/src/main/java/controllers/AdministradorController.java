package controllers;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import models.Administrador;
import models.dao.AdministradorDAO;
import models.Docente;
import models.dao.DocenteDAO;

@WebServlet(urlPatterns = {"/admin"})
public class AdministradorController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private final AdministradorDAO adminDAO = new AdministradorDAO();

    // Mapas para manejar rutas JSP
    private static final Map<String, String> ROUTES = Map.ofEntries(
        Map.entry("/", "loga.jsp"),
        Map.entry("/login", "loga.jsp"),
        Map.entry("/principal", "APrincipal.jsp"),
        Map.entry("/registrardocente", "registrarD.jsp")
        // puedes agregar más páginas aquí
    );

    // Mapas para acciones POST
    private static final Map<String, String> ACTIONS = Map.of(
        "login", "loga.jsp"
        // puedes agregar más acciones aquí
    );

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if (action == null) {
            resp.sendRedirect("admin?action=login");
            return;
        }

        String page = ROUTES.get("/" + action);
        if (page != null) {
            if (action.equals("principal") && !isAdmin(req)) {
                resp.sendRedirect("admin?action=login");
                return;
            }
            forward(req, resp, page);
        } else {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Página no encontrada");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if (action == null) {
            resp.sendRedirect("admin?action=login");
            return;
        }

        switch (action) {
            case "login" -> processLogin(req, resp);
            case "registrardocente" -> registrarDocente(req, resp);
            case "logout" -> processLogout(req, resp);
            default -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    // Procesa login administrador
    private void processLogin(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String correo = req.getParameter("correo");
        String clave = req.getParameter("clave");

        Administrador admin = adminDAO.login(correo, clave);

        if (admin != null) {
            req.getSession().setAttribute("usuario", admin);
            resp.sendRedirect("admin?action=principal");
        } else {
            req.setAttribute("error", "Correo o clave inválidos.");
            forward(req, resp, "loga.jsp");
        }
    }

    // Procesa logout
    private void processLogout(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        req.getSession().invalidate();
        resp.sendRedirect("admin?action=login");
    }

    // Método para validar si hay admin en sesión
    private boolean isAdmin(HttpServletRequest req) {
        Object usuario = req.getSession().getAttribute("usuario");
        return usuario instanceof Administrador;
    }
    
    private void registrarDocente(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

       String nombres = req.getParameter("nombres");
       String apellidoPaterno = req.getParameter("apellidoPaterno");
       String apellidoMaterno = req.getParameter("apellidoMaterno");
       String correo = req.getParameter("correo");
       String dni = req.getParameter("dni");
       String telefono = req.getParameter("telefono");
       int escuelaId = Integer.parseInt(req.getParameter("escuelaId"));
       int idUsuario = 0; // o el valor adecuado si tienes sistema de usuarios

       String claveGenerada = generarClave(8);

       Docente docente = new Docente();
       docente.setNombres(nombres);
       docente.setApellidoPaterno(apellidoPaterno);
       docente.setApellidoMaterno(apellidoMaterno);
       docente.setCorreo(correo);
       docente.setDni(dni);
       docente.setTelefono(telefono);
       docente.setEscuelaId(escuelaId);
       docente.setIdUsuario(idUsuario); // si tienes esa lógica
       docente.setClave(claveGenerada);

        try {
            DocenteDAO dao = new DocenteDAO();
            dao.registrar(docente);  // O tu método correspondiente
            enviarCorreo(correo, claveGenerada);
            req.setAttribute("mensaje", "Docente registrado y correo enviado.");
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Error al registrar docente.");
        }

        req.getRequestDispatcher("/views/registroD.jsp").forward(req, resp);
    }
    
        private String generarClave(int longitud) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder clave = new StringBuilder();
        for (int i = 0; i < longitud; i++) {
            int index = (int) (Math.random() * chars.length());
            clave.append(chars.charAt(index));
        }
        return clave.toString();
    }
    
    private void enviarCorreo(String destino, String clave) {
        final String remitente = "hacapoxd@gmail.com"; // TODO: cambia por tu correo real
        final String password = "pdranqzujuxeawwt"; // ⚠️ Usa una clave de aplicación, NO tu contraseña normal

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente, "SISPREP - Registro"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destino));
            message.setSubject("Registro exitoso - Contraseña de acceso");
            message.setText("Hola,\n\nTu registro fue exitoso en el sistema SISPREP.\n\nTu contraseña temporal es: "
                    + clave + "\n\nTe recomendamos cambiarla una vez que inicies sesión.\n\nGracias.");

            Transport.send(message);
            System.out.println("✅ Correo enviado a " + destino);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Error al enviar correo a " + destino);
        }
    }
    
    // Método para forward simple
    private void forward(HttpServletRequest req, HttpServletResponse resp, String page)
            throws ServletException, IOException {
        req.getRequestDispatcher("/views/" + page).forward(req, resp);
    }
}

