package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Estudiante;
import models.dao.EstudianteDAO;
// Servicios implementados como métodos privados
import java.io.IOException;
import java.util.Map;

public class EstudianteController extends HttpServlet {

    public Estudiante login(HttpServletRequest req) {
        String codigo_UNV = req.getParameter("codigo_UNV");
        String clave = req.getParameter("clave");

        EstudianteDAO dao = new EstudianteDAO();
        Estudiante estudiante = dao.login(codigo_UNV, clave);  // DAO que consulta en BD

        return estudiante;
    } 
}
