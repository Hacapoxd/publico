
package controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.dao.JuradoAsignacionDAO;
import models.dao.NotificacionDAO;

@WebServlet("/coordinador/*")
public class CoordinadorController extends HttpServlet {

    private final NotificacionDAO notifDao = new NotificacionDAO();
    private final JuradoAsignacionDAO juradoDao = new JuradoAsignacionDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        switch(req.getPathInfo()) {
            case "/notificaciones" -> {
            }
            case "/estadisticas" -> {
            }
            default -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        // listar notificaciones
        // mostrar dashboards
            }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        switch(req.getPathInfo()) {
            case "/enviarNotificacion" -> {
            }
            case "/asignarJurado" -> {
            }
            default -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        // notifDao.insertar(...)
        // juradoDao.insertar(...)
            }

}
