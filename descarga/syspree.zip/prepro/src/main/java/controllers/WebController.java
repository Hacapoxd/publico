package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import controllers.EstudianteController;
import models.Estudiante;
import models.dao.EstudianteDAO;
// Servicios implementados como métodos privados
import java.io.IOException;
import java.util.Map;

@WebServlet(urlPatterns = {"/web"})
public class WebController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    // Mapas para reducir código repetitivo
    private static final Map<String, String> ROUTES = Map.ofEntries(
        Map.entry("/", "login.jsp"),
        Map.entry("/index", "login.jsp"),
        Map.entry("/syspre", "syspre.jsp"),
        Map.entry("/login", "login.jsp"),
        Map.entry("/registro", "registro.jsp"),
        Map.entry("/alumno", "alumno.jsp"),
        Map.entry("/registroo", "registroo.jsp"),
        Map.entry("/asignarasesor", "asignarasesor.jsp"),
        Map.entry("/docente", "docente.jsp"),
        Map.entry("/informefinal", "informefinal.jsp"),
        Map.entry("/loga", "loga.jsp"),
        Map.entry("/logc", "logc.jsp"),
        Map.entry("/logd", "logd.jsp"),
        Map.entry("/loge", "loge.jsp"),
        Map.entry("/miprogreso", "miprogeso.jsp"),
        Map.entry("/missuntencaciones", "missustentaciones.jsp"),
        Map.entry("/planReg2", "planReg2.jsp"),
        Map.entry("/reportesemanal", "reportesemanal.jsp"),
        Map.entry("/supervisionestudiante", "supervisionestudiante.jsp"),
        Map.entry("/DPrincipal", "DPrincipal.jsp")
    );
    
    private static final Map<String, String> ACTIONS = Map.of(
        "iniciarSesion", "login.jsp",
        "registrarse", "registro.jsp"
    );

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if (action == null) {
            res.sendRedirect("web?action=syspre");
            return;
        }

        switch (action) {
            case "guardar":
                processGuardarEstudiante(req, res);
                break;
            case "logear":
                processLoginEstudiante(req, res);
                break;
            default:
                res.sendRedirect("web?action=syspre");
        }
    }
    
@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {

        String action = req.getParameter("action"); // Por ejemplo "syspre"

        if (action != null) {
            String page = ROUTES.get("/" + action); // Busca la JSP en el mapa con "/syspre"
            if (page != null) {
                forward(req, res, page);
                return;
            } else {
                // Si no encuentra la ruta en el mapa, manda a una página de error o default
                res.sendError(HttpServletResponse.SC_NOT_FOUND, "Página no encontrada");
                return;
            }
        }

        // Si no hay action, puedes decidir qué mostrar por defecto
        res.sendRedirect("web?action=loge");
    }

    // === MÉTODOS DE PROCESAMIENTO POST ===

    private void processGuardarEstudiante(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        Estudiante estudiante = new Estudiante();
        estudiante.setCodigoUnv(req.getParameter("codigoUnv"));
        estudiante.setSemestreMatriculado(req.getParameter("semestreMatriculado"));
        estudiante.setApellidoPaterno(req.getParameter("apellidoPaterno"));
        estudiante.setApellidoMaterno(req.getParameter("apellidoMaterno"));
        estudiante.setNombres(req.getParameter("nombres"));
        estudiante.setDni(req.getParameter("dni"));
        estudiante.setCelular(req.getParameter("celular"));
        estudiante.setCorreo(req.getParameter("correo"));
        estudiante.setDireccion(req.getParameter("direccion"));
        // Generar clave aleatoria
        String claveGenerada = generarClave(8);
        estudiante.setClave(claveGenerada);

        
        try {
            estudiante.setEscuelaId(Integer.parseInt(req.getParameter("escuelaId")));
        } catch (NumberFormatException e) {
            setError(req, "ID de escuela inválido.");
            res.sendRedirect("web?action=syspre");
            return;
        }

        if (isValidStudent(estudiante) && saveStudent(estudiante)) {
            setMessage(req, "Estudiante registrado exitosamente.");
            enviarCorreo(estudiante.getCorreo(), claveGenerada);
        } else {
            setError(req, "Error al registrar el estudiante.");
        }

        res.sendRedirect("web?action=syspre");
        return;
    }
    
    private boolean saveStudent(Estudiante estudiante) {
        try {
            new EstudianteDAO().registrar(estudiante);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private String generarClave(int longitud) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder clave = new StringBuilder();
        for (int i = 0; i < longitud; i++) {
            int index = (int) (Math.random() * chars.length());
            clave.append(chars.charAt(index));
        }
        return clave.toString();
    }
    
    private void enviarCorreo(String destino, String clave) {
        final String remitente = "hacapoxd@gmail.com"; // TODO: cambia por tu correo real
        final String password = "pdranqzujuxeawwt"; // ⚠️ Usa una clave de aplicación, NO tu contraseña normal

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente, "SISPREP - Registro"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destino));
            message.setSubject("Registro exitoso - Contraseña de acceso");
            message.setText("Hola,\n\nTu registro fue exitoso en el sistema SISPREP.\n\nTu contraseña temporal es: "
                    + clave + "\n\nTe recomendamos cambiarla una vez que inicies sesión.\n\nGracias.");

            Transport.send(message);
            System.out.println("✅ Correo enviado a " + destino);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Error al enviar correo a " + destino);
        }
    }
    
    private void processLoginEstudiante(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        EstudianteController estController = new EstudianteController();
        Estudiante estudiante = estController.login(req);

        if (estudiante != null) {
            // Login exitoso, guardar datos en sesión
            HttpSession session = req.getSession();
            session.setAttribute("usuario", estudiante);
            res.sendRedirect("web?action=alumno");  // página privada para estudiantes
        } else {
            // Login fallido, enviar mensaje de error y volver a login.jsp
            req.setAttribute("error", "codigo-U o contraseña incorrectos");
            res.sendRedirect("web?action=loge");
        }
    }
    public Estudiante login(HttpServletRequest req) {
        String codigo_UNV = req.getParameter("codigo_UNV");
        String clave = req.getParameter("clave");

        EstudianteDAO dao = new EstudianteDAO();
        Estudiante estudiante = dao.login(codigo_UNV, clave);  // DAO que consulta en BD

        return estudiante;
    } 
    
    // === UTILIDADES ===

    private void forward(HttpServletRequest req, HttpServletResponse res, String page) 
            throws ServletException, IOException {
        req.getRequestDispatcher("/views/" + page).forward(req, res);
    }
    
    private boolean isAuthenticated(HttpServletRequest req) {
        return req.getSession().getAttribute("usuario") != null;
    }

    // === MÉTODOS DE BASE DE DATOS ===
 
    private boolean isValidStudent(Estudiante estudiante) {
        // TODO: Validar datos del estudiante
        return estudiante.getCodigoUnv() != null && 
               estudiante.getCorreo() != null && 
               estudiante.getDni() != null;
    }
   
    private void setError(HttpServletRequest req, String message) {
        req.setAttribute("error", message);
    }
    
    private void setMessage(HttpServletRequest req, String message) {
        req.setAttribute("mensaje", message);
    }
    
    private void setAttribute(HttpServletRequest req, String key, String value) {
        req.setAttribute(key, value);
    }
}